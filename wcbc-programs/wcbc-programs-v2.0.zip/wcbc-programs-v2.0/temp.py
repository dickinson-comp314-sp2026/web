# s = 'def f(x): return x*x'
# exec(s)
# v = f(5)
# print(v)


# def g():
#     s = 'def f(x): return x*x'
#     exec(s)
#     v = f(5)
#     print(v)

# def g():
#     s = 'def f(x): return x*x'
#     exec(s, globals())
#     v = f(5)
#     print(v)

# g()

# def g():
#     s = 'def f(x): return x*x'
#     ns = {}
#     exec(s, ns)
#     v = ns
#     print(v)

# g()



import utils; from utils import rf   
from containsGAGA import containsGAGA

# for s in ['GAG', 'GAGA','GGGGAAAA', 'CCTTAAGGAGATT']:
#     print(s, containsGAGA(s))

from universal import universal

result = universal(rf('containsGAGA.py'), 'CCGAGA')
print(result)
