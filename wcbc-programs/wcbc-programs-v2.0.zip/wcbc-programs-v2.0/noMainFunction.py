# Python file noMainFunction.py

# This file is used as an example in section 2.4.
import utils; from utils import rf 
x = 5
y = 7
z = x + y  
