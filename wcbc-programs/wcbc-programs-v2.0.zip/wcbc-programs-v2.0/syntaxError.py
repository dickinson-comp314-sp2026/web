# Python file syntaxError.py

# This file is used as an example in section 2.4.
import utils; from utils import rf
def syntaxError(inString): 
    return 2 * (3 + 5   
