# SISO program convertHaltToPeano.py

# No implementation is provided.  A real implementation of this
# function would be long, tedious, and messy.  However, the discussion
# in the textbook explains how this program could be implemented if
# desired.  If it were implemented, then this function would take as
# input a Python program P, and it would return a Peano arithmetic
# string with the meaning "P halts on empty input."
import utils; from utils import rf
def convertHaltToPeano(inString):
    # No implementation is provided.  A real implementation of this
    # function would be long, tedious, and messy.  However, the
    # discussion on page~\pageref{page:convertHaltToPeano.py} explains
    # how this program could be implemented if desired.
    return 'not implemented'


def testconvertHaltToPeano():
    # Nothing to assert. Execute the function to check for typos or
    # other glaring errors.
    convertHaltToPeano('asdf')
